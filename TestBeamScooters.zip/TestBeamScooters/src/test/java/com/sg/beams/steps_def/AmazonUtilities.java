package com.sg.beams.steps_def;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import java.util.List;


public class AmazonUtilities {
    public WebDriver myDriver;

    public void verifyCartItem(String ItemName) {
        List<WebElement> elementsInCart = myDriver.findElements(By.xpath("//span[@class='a-size-medium sc-product-title a-text-bold']"));
        int sizeInCart = elementsInCart.size();
        for (int index = 0; index < sizeInCart; index++) {
            String textEleInCart = elementsInCart.get(index).getText();
            System.out.println("Elements In Cart::" + textEleInCart);
            if (ItemName.contains(textEleInCart)) {
                System.out.println("The Item Has been Added Succesfully in the Cart");
            }
        }

    }

    public String findSearchViewLayout() {
        String view = "";
        try {
            final WebElement element = myDriver.findElement(By.xpath("//span[@data-component-type='s-search-results']//div[@class='s-result-list sg-row']"));
            if (element != null) {
                view = "Vertical";
            }
        } catch (NoSuchElementException e) {
            System.out.println("Ignore this exception for vertical layout");
            //e.printStackTrace();
        }
        try {
            WebElement element = myDriver.findElement(By.xpath("//ul[@id='s-results-list-atf']"));
            if (element != null) {
                view = "Horizontal";
            }
        } catch (NoSuchElementException e) {
            System.out.println("Ignore this exception for horizontal layout");
        }
        System.out.println("The Search Result Orientation is::" + view);
        return view;
    }


    public void navigateToCart() {
        WebElement elementCart = myDriver.findElement(By.xpath("//div[@id='nav-tools']/a[contains(@href,'cart')]"));
        ((JavascriptExecutor) myDriver).executeScript("arguments[0].click();", elementCart);
    }

    public Integer getCurrentCartCount() {
        String textCount = myDriver.findElement(By.xpath("//span[@id='nav-cart-count']")).getText();
        System.out.println("Current Cart Count is ::" + textCount);
        Integer cartCount = Integer.valueOf(textCount);
        return cartCount;
    }

    public void searchProductOnAmazonWebSite(String productName) {
        myDriver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(productName);
        myDriver.findElement(By.xpath("//input[@value='Go']")).click();
    }

    public Double getCartPriceForNonEmptyCart() {
        // Capture the price
        String textCartPrice = myDriver.findElement(By.xpath("//form[@id='gutterCartViewForm']//span[contains(text(),'$')]")).getText();
        String cartTotal = textCartPrice.replace("$", "");
        Double cTotal = Double.valueOf(cartTotal);
        System.out.println("The Cart Total is ::" + cTotal);
        return cTotal;
    }

    public void buttonCheckAndClick(final String elementXpath, final String elementText) {
        final WebElement element = myDriver.findElement(By.xpath(elementXpath));
        Assert.assertTrue("The " + elementText + "Button is Displayed", element.isDisplayed());
        Assert.assertTrue("The " + elementText + "Button is Enabled", element.isEnabled());
        if ((element.isDisplayed()) && ((element.isEnabled()))) ;
        {
            System.out.println("The Button is Enabled and Displayed And Can be Clicked");
            element.click();
        }
    }

    public void goToAmazonURL() {
        final String strUrl = "https:\\www.amazon.com";
        myDriver.get(strUrl);
    }

    public void getCurrentUrl() {
        myDriver.findElement(By.xpath("//span[@class='nav-sprite nav-logo-base']")).isDisplayed();
        String currentUrl = myDriver.getCurrentUrl();
        System.out.println("Current Navigated URL is ::" + currentUrl);
    }

    public String findAndAddAmazonChoiceItemForHorizontalLayout() {
        final WebElement elementVertical = myDriver.findElement(By.xpath("//ul[@id='s-results-list-atf']"));
        final List<WebElement> liSearch = elementVertical.findElements(By.tagName("li"));
        int searchSizeHZ = liSearch.size();
        System.out.println("The size of search is ::" + searchSizeHZ);
        boolean blnFound = false;
        String textLiSearch = "";
        for (int index = 0; index < searchSizeHZ && !blnFound; index++) {
            textLiSearch = liSearch.get(index).getText();
            // System.out.println("The Text found is::"+textLiSearch);
            if (textLiSearch.contains("Sponsored")){
                System.out.println("Sponsored Item - Ignore for item index ::"+index);
            }
            if (textLiSearch.contains("Best Seller")) {
                System.out.println("Best Seller - - Ignore for item index ::" + index);
            }
            if (textLiSearch.contains("Amazon's Choice")){
            //if (textLiSearch.contains("Sponsored")) {
                System.out.println("The Text found is::" + textLiSearch);
                System.out.println("Amazon`s Choice Please Buy::" + index);
                blnFound = true;
                WebElement elementToBuy = myDriver.findElement(By.xpath("//li[@id='result_" + index + "']//a[contains(@title,'Sharpener')]"));
                elementToBuy.click();

                String textCount1 = myDriver.findElement(By.xpath("//span[@id='nav-cart-count']")).getText();
                System.out.println("Current Cart Count is ::" + textCount1);
                buttonCheckAndClick("//div[@class='a-section a-spacing-none a-padding-none']//input[@title='Add to Shopping Cart']", "Add to Cart Button");
                String textCount2 = myDriver.findElement(By.xpath("//span[@id='nav-cart-count']")).getText();
                System.out.println("Current Cart Count is ::" + textCount2);

                Integer CartValue = Integer.valueOf(textCount2) - Integer.valueOf(textCount1);
                if (CartValue == 1) {
                    System.out.println("The Cart Value increased by One");
                }

            }
        }
        return textLiSearch;
    }

    public String findAndAddAmazonChoiceItemForVerticalLayout() {
        String textLiSearch = "";
        List<WebElement> liSearch = myDriver.findElements(By.xpath("//div[contains(@data-cel-widget,'search_result')]"));
        int searchSizeVR = liSearch.size();
        System.out.println("The size of search is ::" + searchSizeVR);
        boolean blnFound = false;
        for (int index = 0; index < searchSizeVR && !blnFound; index++) {
            textLiSearch = liSearch.get(index).getText();
            // System.out.println("The Text found is::"+textLiSearch);
            if (textLiSearch.contains("Sponsored")){
                System.out.println("Sponsored Item - Ignore for item index ::"+index);
                blnFound = false;
            }
            if (textLiSearch.contains("Best Seller")) {
                System.out.println("Best Seller - - Ignore for item index ::" + index);
                blnFound = false;
            }
            //if (textLiSearch.contains("Sponsored")) {
            if (textLiSearch.contains("Amazon's Choice")){
                System.out.println("The Text found is::"+textLiSearch);
                System.out.println("Amazon`s Choice Please Buy::"+index);
                //liSearch.get(i).findElement(By.tagName("a")).getAttribute("href")
                blnFound = true;//problem code TODO
                WebElement elementToBuy = liSearch.get(index).findElement(By.tagName("a"));
                elementToBuy.isDisplayed();
                elementToBuy.isEnabled();
                elementToBuy.click();
                //Wait
                String textCount1 = myDriver.findElement(By.xpath("//span[@id='nav-cart-count']")).getText();
                System.out.println("Current Cart Count is ::"+textCount1);
                buttonCheckAndClick ("//div[@class='a-section a-spacing-none a-padding-none']//input[@title='Add to Shopping Cart']","Add to Cart Button");
                String textCount2 = myDriver.findElement(By.xpath("//span[@id='nav-cart-count']")).getText();
                System.out.println("Current Cart Count is ::"+textCount2);

                Integer CartValue = Integer.valueOf(textCount2)-Integer.valueOf(textCount1);
                if (CartValue == 1){
                    System.out.println("The Cart Value increased by One");
                }


            }

        }
        return textLiSearch;
    }

    public void removeTheProduct() {
        WebElement elementProduct = myDriver.findElement(By.xpath("//*[@id=\"activeCartViewForm\"]//child::input[@type='submit'][@value='Delete']"));
        elementProduct.click();
    }

    public void updateCart(Integer updatedCartQuantity) {

        if (getCurrentCartCount() < 10 && updatedCartQuantity < 10) {
            // if the current cart qty <10 and updated qty <10, the qty is available via dropdown
            Select qtyDropDown = new Select(myDriver.findElement(By.name("quantity")));
            qtyDropDown.selectByVisibleText(String.valueOf(updatedCartQuantity));
            BeamWait.waitForSeconds(myDriver, 10);
        } else if (getCurrentCartCount() < 10 && updatedCartQuantity >= 10) {
            // if the current cart qty <10 and updated qty >=10, then update is disabled and manually update the quantity
            Select qtyDropDown = new Select(myDriver.findElement(By.name("quantity")));
            qtyDropDown.selectByVisibleText("10+");
            myDriver.findElement(By.xpath("//input[@name='quantityBox']")).sendKeys(String.valueOf(updatedCartQuantity));
            myDriver.findElement(By.xpath("//*[@id=\"activeCartViewForm\"]//a[contains(text(),'Update')]")).isDisplayed();
            myDriver.findElement(By.xpath("//*[@id=\"activeCartViewForm\"]//a[contains(text(),'Update')]")).isEnabled();
            myDriver.findElement(By.xpath("//*[@id=\"activeCartViewForm\"]//a[contains(text(),'Update')]")).click();
            BeamWait.waitForSeconds(myDriver, 10);
        } else if (getCurrentCartCount() >= 10 && updatedCartQuantity >= 10) {
            // if the current cart qty >=10 and updated qty >=10, then clear the qtybox and manually update the value
            WebElement qtyElement = myDriver.findElement(By.xpath("//input[@name='quantityBox']"));
            JavascriptExecutor executor = (JavascriptExecutor) myDriver;
            executor.executeScript("arguments[0].value='';", qtyElement);
            executor.executeScript("arguments[0].value='" + updatedCartQuantity + "';", qtyElement);
            myDriver.findElement(By.xpath("//input[@name='quantityBox']")).sendKeys(Keys.ENTER);
        } else if (getCurrentCartCount() >= 10 && updatedCartQuantity < 10) {
            // if the current cart qty >=10 and updated qty <10, then update is disabled and manually update the quantity
            WebElement qtyElement = myDriver.findElement(By.xpath("//input[@name='quantityBox']"));
            JavascriptExecutor executor = (JavascriptExecutor) myDriver;
            executor.executeScript("arguments[0].value='';", qtyElement);
            executor.executeScript("arguments[0].value='" + updatedCartQuantity + "';", qtyElement);
            myDriver.findElement(By.xpath("//input[@name='quantityBox']")).sendKeys(Keys.ENTER);
        }
    }

}

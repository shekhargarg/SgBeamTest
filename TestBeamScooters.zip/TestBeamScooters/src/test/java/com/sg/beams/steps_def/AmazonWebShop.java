package com.sg.beams.steps_def;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class AmazonWebShop {
    @Given("^Browser is launched$")
    public void browser_is_launched() throws Throwable {
        Assert.assertTrue("Browser is not launched.", (CucumberHooks.getMyDriver().getWindowHandle() != null));
    }

    @When("^I Navigate to Amazon page$")
    public void i_Navigate_to_Amazon_page() throws Throwable {
        CucumberHooks.getAmazonUtilities().goToAmazonURL();
    }

    @Then("^Amazon page is displayed$")
    public void amazon_page_is_displayed() throws Throwable {
        CucumberHooks.getAmazonUtilities().getCurrentUrl();
    }


    @Then("^Search for product is visible$")
    public void search_for_product_is_visible() throws Throwable {
        System.out.println("Executing - Search Functionality");
        String vProduct = "X-ACTO School Pro Classroom Electric Pencil Sharpener";
        CucumberHooks.getAmazonUtilities().getCurrentUrl();
        CucumberHooks.getAmazonUtilities().getCurrentCartCount();
        CucumberHooks.getAmazonUtilities().searchProductOnAmazonWebSite(vProduct);
        BeamWait.waitForSeconds(CucumberHooks.getMyDriver(), 15);
        CucumberHooks.getAmazonUtilities().findSearchViewLayout();
    }

    @Then("^The Product is added to cart$")
    public void the_Product_is_added_to_cart() throws Throwable {
        String viewRes = CucumberHooks.getAmazonUtilities().findSearchViewLayout();
        String textLiSearch = "";
        if ("Vertical".equalsIgnoreCase(viewRes)) {
            textLiSearch = CucumberHooks.getAmazonUtilities().findAndAddAmazonChoiceItemForVerticalLayout();
        } else {
            textLiSearch = CucumberHooks.getAmazonUtilities().findAndAddAmazonChoiceItemForHorizontalLayout();
        }
        //Navigate to Cart
        CucumberHooks.getAmazonUtilities().navigateToCart();
        //get the items names from cart
        CucumberHooks.getAmazonUtilities().verifyCartItem(textLiSearch);
        //CucumberHooks.getAmazonUtilities().getCartPriceForNonEmptyCart();
    }

    @Then("^the Cart count is increased$")
    public void the_Cart_count_is_increased() throws Throwable {
        CucumberHooks.getAmazonUtilities().getCartPriceForNonEmptyCart();
    }

    @Then("^remove Product and verify the cart$")
    public void the_Product_is_removed() throws Throwable {
        Integer addedCartItemCount = CucumberHooks.getAmazonUtilities().getCurrentCartCount();
        Double addedCartPrice = CucumberHooks.getAmazonUtilities().getCartPriceForNonEmptyCart();
        Double removedCartPrice = 0.0;

        System.out.println("Initial Cart Count is::" + addedCartItemCount);
        System.out.println("Initial Cart Price is::" + addedCartPrice);

        CucumberHooks.getAmazonUtilities().removeTheProduct();
        Integer removedCartItemCount = CucumberHooks.getAmazonUtilities().getCurrentCartCount();
        if (removedCartItemCount == 0) {
            removedCartPrice = 0.0;
        } else {
            removedCartPrice = CucumberHooks.getAmazonUtilities().getCartPriceForNonEmptyCart();
        }
        if (addedCartItemCount > removedCartItemCount) {
            System.out.println("The Cart Count is Correct After one Product is removed");
        } else {
            System.out.println("The Cart Count is Incorrect Correct After one Product is removed");
        }
        if (addedCartPrice >= removedCartPrice) {
            System.out.println("The Cart Price is Correct After one Product is removed");
        } else {
            System.out.println("The Cart Price is InCorrect After one Product is removed");
        }
    }

    @Then("^Product Count is increased to (\\d+)$")
    //@Then("^Product Count is increased to \"(.*?)\"$")
    public void product_Count_is_increased_to(Integer valueInp) throws Throwable {
        Integer addedCartItemCount = CucumberHooks.getAmazonUtilities().getCurrentCartCount();
        Double addedCartPrice = CucumberHooks.getAmazonUtilities().getCartPriceForNonEmptyCart();
        System.out.println("Initial Cart Count is::" + addedCartItemCount);
        System.out.println("Initial Cart Price is::" + addedCartPrice);

        CucumberHooks.getAmazonUtilities().updateCart(Integer.valueOf(valueInp));
        Integer itemCountAfterAddingItems = CucumberHooks.getAmazonUtilities().getCurrentCartCount();
        Double cartPriceAfterAddingItems = CucumberHooks.getAmazonUtilities().getCartPriceForNonEmptyCart();
        System.out.println("Cart Count after adding "+valueInp+" Quantities is::" + itemCountAfterAddingItems);
        System.out.println("Cart Price after adding "+valueInp+" Quantities is::" + cartPriceAfterAddingItems);
    }

}
